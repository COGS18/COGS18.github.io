"""Test for my functions.

Note: because these are 'empty' functions (return None), here we just test
  that the functions execute, and return None, as expected.
"""

from functions import my_func, my_other_func

##
##

def test_my_func():

    assert my_func() == None

def test_my_other_func():

    assert my_other_func() == None
