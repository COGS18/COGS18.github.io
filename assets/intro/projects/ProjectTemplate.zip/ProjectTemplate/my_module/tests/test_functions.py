"""Test for my functions."""

def test_my_func():

    assert my_func()

def test_my_other_func():

    assert my_other_func()
