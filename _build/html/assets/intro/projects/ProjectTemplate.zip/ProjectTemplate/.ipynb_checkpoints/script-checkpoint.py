"""Script to run some part of my project."""

# Imports
from module import my_func, my_other_func

###
###

# PYTHON SCRIPT HERE

pass
