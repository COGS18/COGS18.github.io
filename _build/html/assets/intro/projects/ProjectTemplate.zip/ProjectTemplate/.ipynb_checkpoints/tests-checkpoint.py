"""Unit tests to test functionality of project.
"""

import unittest

import module
##
##



                 
    